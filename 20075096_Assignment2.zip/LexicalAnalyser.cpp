#include <bits/stdc++.h>
using namespace std;

// Token types
enum TokenType { TOKEN_UNKNOWN, TOKEN_KEYWORD_DCL, TOKEN_KEYWORD_FIXED, TOKEN_KEYWORD_CHAR, TOKEN_KEYWORD_IF, TOKEN_KEYWORD_THEN, TOKEN_KEYWORD_ELSE,
                 TOKEN_KEYWORD_DO, TOKEN_KEYWORD_TO, TOKEN_KEYWORD_END, TOKEN_KEYWORD_PUT, TOKEN_KEYWORD_SKIP, TOKEN_KEYWORD_LIST, TOKEN_KEYWORD_BIT,
                 TOKEN_KEYWORD_BIN, TOKEN_KEYWORD_BOOLEAN, TOKEN_KEYWORD_FLOAT, TOKEN_KEYWORD_DOUBLE, TOKEN_KEYWORD_ARRAY, TOKEN_IDENTIFIER, TOKEN_NUMBER, 
                 TOKEN_STRING, TOKEN_OPERATOR, TOKEN_PUNCTUATION, TOKEN_COMMENT
};

// Token structure
struct Token {
    TokenType type;
    string lexeme;
};

// Function to check if a string is a keyword
TokenType checkKeyword(string &word) {
    if (word == "DCL") return TOKEN_KEYWORD_DCL;
    if (word == "FIXED") return TOKEN_KEYWORD_FIXED;
    if (word == "CHAR") return TOKEN_KEYWORD_CHAR;
    if (word == "IF") return TOKEN_KEYWORD_IF;
    if (word == "THEN") return TOKEN_KEYWORD_THEN;
    if (word == "ELSE") return TOKEN_KEYWORD_ELSE;
    if (word == "DO") return TOKEN_KEYWORD_DO;
    if (word == "TO") return TOKEN_KEYWORD_TO;
    if (word == "END") return TOKEN_KEYWORD_END;
    if (word == "PUT") return TOKEN_KEYWORD_PUT;
    if (word == "SKIP") return TOKEN_KEYWORD_SKIP;
    if (word == "LIST") return TOKEN_KEYWORD_LIST;
    if (word == "FIXED") return TOKEN_KEYWORD_FIXED;
    if (word == "BIT") return TOKEN_KEYWORD_BIT;
    if (word == "BIN") return TOKEN_KEYWORD_BIN;
    if (word == "BOOLEAN") return TOKEN_KEYWORD_BOOLEAN;
    if (word == "FLOAT") return TOKEN_KEYWORD_FLOAT;
    if (word == "DOUBLE") return TOKEN_KEYWORD_DOUBLE;
    if (word == "ARRAY") return TOKEN_KEYWORD_ARRAY;
    return TOKEN_IDENTIFIER;
}

// Function to check if a character is an operator
bool isOperator(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/' ||
           c == '=' || c == '<' || c == '>' || c == '&' ||
           c == '|' || c == '^' || c == '#' || c == '%';
}

// Function to check if a character is a punctuation symbol
bool isPunctuation(char c) {
    return c == '(' || c == ')' || c == '[' || c == ']' ||
           c == '{' || c == '}' || c == ';' || c == ',' ||
           c == ':' || c == '.' || c == '?' || c == '!';
}

// Lexical analyzer function
vector<Token> tokenize(string &input) {
    vector<Token> tokens;
    size_t pos = 0;

    while (pos < input.size()) {
        char currentChar = input[pos];

        // Skip whitespace characters
        if (isspace(currentChar)) {
            ++pos;
            continue;
        }

        // Check for comments
        if (currentChar == '/') {
            if (pos + 1 < input.size() && input[pos + 1] == '*') {
                size_t endPos = pos + 2;
                while (endPos + 1 < input.size() && !(input[endPos] == '*' && input[endPos + 1] == '/')) {
                    ++endPos;
                }
                endPos += 2;

                Token token;
                token.type = TOKEN_COMMENT;
                token.lexeme = input.substr(pos, endPos - pos);

                tokens.push_back(token);
                pos = endPos;
                continue;
            }
        }

        // Check for string literals
        if (currentChar == '\'') {
            size_t endPos = pos + 1;
            while (endPos < input.size() && input[endPos] != '\'') {
                ++endPos;
            }
            if (endPos < input.size()) {
                Token token;
                token.type = TOKEN_STRING;
                token.lexeme = input.substr(pos, endPos - pos + 1);

                tokens.push_back(token);
                pos = endPos + 1;
                continue;
            }
        }

        // Check for keywords or identifiers
        if (isalpha(currentChar)) {
            size_t endPos = pos;
            while (endPos < input.size() && (isalnum(input[endPos]) || input[endPos] == '_')) {
                ++endPos;
            }

            string word = input.substr(pos, endPos - pos);
            TokenType tokenType = checkKeyword(word);

            Token token;
            token.type = tokenType;
            token.lexeme = word;

            tokens.push_back(token);
            pos = endPos;
            continue;
        }

        // Check for numbers
        if (isdigit(currentChar)) {
            size_t endPos = pos;
            while (endPos < input.size() && (isdigit(input[endPos]) || input[endPos] == '.')) {
                ++endPos;
            }

            string number = input.substr(pos, endPos - pos);
            Token token;
            token.type = TOKEN_NUMBER;
            token.lexeme = number;

            tokens.push_back(token);
            pos = endPos;
            continue;
        }

        // Check for operators
        if (isOperator(currentChar)) {
            size_t endPos = pos;
            while (endPos < input.size() && isOperator(input[endPos])) {
                ++endPos;
            }

            string op = input.substr(pos, endPos - pos);
            Token token;
            token.type = TOKEN_OPERATOR;
            token.lexeme = op;

            tokens.push_back(token);
            pos = endPos;
            continue;
        }

        // Check for punctuation symbols
        if (isPunctuation(currentChar)) {
            Token token;
            token.type = TOKEN_PUNCTUATION;
            token.lexeme = currentChar;

            tokens.push_back(token);
            ++pos;
            continue;
        }

        ++pos;
    }

    return tokens;
}

int main() {
    ifstream inputFile("input_file.pli");
    if (!inputFile.is_open()) {
        cerr << "Error opening input file." << endl;
        return 1;
    }

    string line;
    string input;

    while (std::getline(inputFile, line)) {
        input += line;
        input += ' ';
    }

    inputFile.close();
    
    vector<Token> tokens = tokenize(input);

    for (const Token &token : tokens) {
        string tokenType;
        switch (token.type) {
            case TOKEN_KEYWORD_DCL:
                tokenType = "KEYWORD_DCL";
                break;
            case TOKEN_KEYWORD_FIXED:
                tokenType = "KEYWORD_FIXED";
                break;
            case TOKEN_KEYWORD_CHAR:
                tokenType = "KEYWORD_CHAR";
                break;
            case TOKEN_KEYWORD_IF:
                tokenType = "KEYWORD_IF";
                break;
            case TOKEN_KEYWORD_THEN:
                tokenType = "KEYWORD_THEN";
                break;
            case TOKEN_KEYWORD_ELSE:
                tokenType = "KEYWORD_ELSE";
                break;
            case TOKEN_KEYWORD_DO:
                tokenType = "KEYWORD_DO";
                break;
            case TOKEN_KEYWORD_TO:
                tokenType = "KEYWORD_TO";
                break;
            case TOKEN_KEYWORD_END:
                tokenType = "KEYWORD_END";
                break;
            case TOKEN_KEYWORD_PUT:
                tokenType = "KEYWORD_PUT";
                break;
            case TOKEN_KEYWORD_SKIP:
                tokenType = "KEYWORD_SKIP";
                break;
            case TOKEN_KEYWORD_LIST:
                tokenType = "KEYWORD_LIST";
                break;
            case TOKEN_KEYWORD_BIT:
                tokenType = "KEYWORD_BIT";
                break;
            case TOKEN_KEYWORD_BIN:
                tokenType = "KEYWORD_BIN";
                break;
            case TOKEN_KEYWORD_BOOLEAN:
                tokenType = "KEYWORD_BOOLEAN";
                break;
            case TOKEN_KEYWORD_FLOAT:
                tokenType = "KEYWORD_FLOAT";
                break;
            case TOKEN_KEYWORD_DOUBLE:
                tokenType = "KEYWORD_DOUBLE";
                break;
            case TOKEN_KEYWORD_ARRAY:
                tokenType = "KEYWORD_ARRAY";
                break;
            case TOKEN_IDENTIFIER:
                tokenType = "IDENTIFIER";
                break;
            case TOKEN_NUMBER:
                tokenType = "NUMBER";
                break;
            case TOKEN_STRING:
                tokenType = "STRING";
                break;
            case TOKEN_OPERATOR:
                tokenType = "OPERATOR";
                break;
            case TOKEN_PUNCTUATION:
                tokenType = "PUNCTUATION";
                break;
            case TOKEN_COMMENT:
                tokenType = "COMMENT";
                break;
            default:
                tokenType = "UNKNOWN";
        }

        cout << "Type: " << tokenType << ", Lexeme: " << token.lexeme << endl;
    }

    return 0;
}